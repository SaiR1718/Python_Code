def fun():
    print("lambda function")