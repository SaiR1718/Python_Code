import json
import boto3

s3=boto3.resource("s3")

def lambda_handler(event,context):
	bucket_list=[]
	for bucket ins3.buckets.all():
		bucket_list.append(bucket.name)
	print(json.dumps(bucketlist))
	return {
		"statusCode": 200,
		"body": bucketlist
	}